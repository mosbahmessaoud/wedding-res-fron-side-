import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wedding_reservation_app/screens/auth/forgot_password_screen.dart';
import 'package:wedding_reservation_app/screens/auth/sing_up_screen.dart';
import 'package:wedding_reservation_app/screens/auth/welcome_screen.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/home_screen.dart';
import 'package:wedding_reservation_app/screens/groom/groom_home_screen.dart';
import 'package:wedding_reservation_app/screens/super%20admin/home_screen.dart';
import 'package:wedding_reservation_app/services/notification_manager.dart';
import 'package:wedding_reservation_app/services/token_manager.dart';

import 'package:wedding_reservation_app/services/notification_service.dart';
import 'package:wedding_reservation_app/services/foreground_notification_service.dart';

import '../../services/api_service.dart';
import '../../widgets/common/custom_text_field.dart';
import '../../widgets/theme_toggle_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> with SingleTickerProviderStateMixin  {
  final _formKey = GlobalKey<FormState>();
  final _phoneController = TextEditingController();
  final _passwordController = TextEditingController();
  
    // ADD THESE:
  late AnimationController _animationController;
  late Animation<double> slideAnimation;
  late Animation<double> fadeAnimation;

  bool _isLoading = false;
  bool _obscurePassword = true;

  static const String _keyLastPhone = 'last_login_phone';

  // @override
  // void initState() {
  //   super.initState();
  //   _loadLastPhone();
  // }
// @override
// void initState() {
//   super.initState();
//   _loadLastPhone();
  
//   _animationController = AnimationController(
//     duration: const Duration(milliseconds: 400), // Very fast
//     vsync: this,
//   );

//   slideAnimation = Tween<double>(begin: 10.0, end: 0.0).animate( // Minimal slide
//     CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
//   );

//   fadeAnimation = Tween<double>(begin: 0.7, end: 1.0).animate( // Start at 70% opacity instead of 0%
//     CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
//   );

//   _animationController.forward(); // Start immediately
// }

@override
void initState() {
  super.initState();
  _loadLastPhone();
  _checkExistingAuth(); // ADD THIS
  
  _animationController = AnimationController(
    duration: const Duration(milliseconds: 400),
    vsync: this,
  );

  slideAnimation = Tween<double>(begin: 10.0, end: 0.0).animate(
    CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
  );

  fadeAnimation = Tween<double>(begin: 0.7, end: 1.0).animate(
    CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
  );

  _animationController.forward();
}
  @override
  void dispose() {
    _phoneController.dispose();
    _passwordController.dispose();
    _animationController.dispose(); // ADD THIS LINE

    super.dispose();
  }

  // Load last logged-in phone number
  Future<void> _loadLastPhone() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final lastPhone = prefs.getString(_keyLastPhone);
      
      if (lastPhone != null && lastPhone.isNotEmpty) {
        _phoneController.text = lastPhone;
      }
    } catch (e) {
      print('Error loading last phone');
    }
  }

  // Save phone number for next login
  Future<void> _saveLastPhone(String phone) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyLastPhone, phone);
    } catch (e) {
      print('Error saving phone number');
    }
  }

  // void _showSnack(String msg, bool isError) {
  //   if (!mounted) return;
  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(
  //       content: Row(
  //         children: [
  //           Icon(isError ? Icons.error_outline : Icons.check_circle, color: Colors.white),
  //           const SizedBox(width: 12),
  //           Expanded(child: Text(msg)),
  //         ],
  //       ),
  //       backgroundColor: isError ? Colors.red.shade600 : Colors.green.shade600,
  //       behavior: SnackBarBehavior.floating,
  //       shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
  //       margin: const EdgeInsets.all(16),
  //     ),
  //   );
  // }


void _showSnack(String msg, bool isError) {
  if (!mounted) return;

  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar() // optional: prevents stacking
    ..showSnackBar(
      SnackBar(
        duration: const Duration(seconds: 4), 
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle,
              color: Colors.white,
            ),
            const SizedBox(width: 12),
            Expanded(child: Text(msg)),
          ],
        ),
        backgroundColor:
            isError ? Colors.red.shade600 : Colors.green.shade600,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
}



// added new 

// ─────────────────────────────────────────────────────────────────
// Replace _checkExistingAuth()
// ─────────────────────────────────────────────────────────────────
Future<void> _checkExistingAuth() async {
  try {
    final hasValid = await TokenManager.hasValidToken();
    if (!hasValid) return;

    final token = await TokenManager.getToken();
    if (token == null) return;

    final role = TokenManager.getRoleFromToken(token);
    if (role == null) return;

    if (!mounted) return;

    // ── NEW: start notification services for the already-logged-in user ──
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('user_role', role);
    // Token is already persisted; just re-initialise ApiService headers
    await ApiService.initializeToken();

    // Fire-and-forget: start monitoring without blocking navigation
    WeddingNotificationService()
        .forceImmediateCheck()
        .catchError((e) => print('Notification check error: $e'));

    WeddingForegroundNotificationService()
        .startService()
        .catchError((e) => print('Foreground service error: $e'));

    Widget destination;
    switch (role) {
      case 'groom':
        destination = const GroomHomeScreen(initialTabIndex: 0);
        break;
      case 'super_admin':
        destination = const SuperAdminHomeScreen();
        break;
      case 'clan_admin':
        destination = const ClanAdminHomeScreen();
        break;
      default:
        return; // Unknown role — stay on login
    }

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => destination,
        transitionsBuilder: (_, animation, __, child) =>
            FadeTransition(opacity: animation, child: child),
        transitionDuration: const Duration(milliseconds: 200),
      ),
    );
  } catch (e) {
    print('Auto-login check failed: $e');
    // Stay on login screen silently
  }
}

// ─────────────────────────────────────────────────────────────────
// Replace _login()
// ─────────────────────────────────────────────────────────────────
Future<void> _login() async {
  if (!_formKey.currentState!.validate()) return;

  setState(() => _isLoading = true);

  try {
    final phone = _phoneController.text.trim();
    final response = await ApiService.login(phone, _passwordController.text);

    if (!mounted) return;

    // Persist phone for next login
    await _saveLastPhone(phone);

    // Decode JWT to get role
    final token = response['access_token'] as String;
    final parts = token.split('.');
    final payload = json.decode(
      utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))),
    );
    final role = payload['role'] as String;

    // ── NEW: persist role + kick off notification services ──
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
    await prefs.setString('user_role', role);

    // Fire-and-forget — don't await so navigation isn't blocked
    WeddingNotificationService()
        .forceImmediateCheck()
        .catchError((e) => print('Notification check error: $e'));

    WeddingForegroundNotificationService()
        .startService()
        .catchError((e) => print('Foreground service error: $e'));

    // Navigate based on role
    Widget destination;
    switch (role) {
      case 'groom':
        destination = const GroomHomeScreen(initialTabIndex: 0);
        break;
      case 'super_admin':
        destination = const SuperAdminHomeScreen();
        break;
      case 'clan_admin':
        destination = const ClanAdminHomeScreen();
        break;
      default:
        throw Exception('دور المستخدم غير معروف');
    }

    Navigator.of(context).pushReplacement(
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => destination,
        transitionsBuilder: (_, animation, __, child) =>
            FadeTransition(opacity: animation, child: child),
        transitionDuration: const Duration(milliseconds: 200),
      ),
    );
  } catch (e) {
    if (!mounted) return;
    setState(() => _isLoading = false);
    _showSnack('خطأ في تسجيل الدخول، تحقق من الإنترنت.', true);
  }
}


String? validatePhone(String? value) {
  if (value == null || value.isEmpty) {
    return 'رقم الهاتف مطلوب';
  }
  return null;
}
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final size = MediaQuery.of(context).size;
    final isLargeScreen = size.width >= 750;
    
    return Scaffold(
      body: SizedBox.expand(
        child: Container(
          decoration: BoxDecoration(
            image: !isLargeScreen 
              ? DecorationImage(
                  image: const AssetImage('assets/images/IMG_2838.JPG'),
                  fit: BoxFit.cover,
                  colorFilter: ColorFilter.mode(
                    isDark 
                      ? const Color.fromARGB(120, 0, 0, 0) 
                      : const Color.fromARGB(55, 255, 255, 255),
                    BlendMode.overlay,
                  ),
                ) 
              : null,
          ),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: isDark
                  ? (isLargeScreen
                      ? [
                          Colors.black.withOpacity(0.7),
                          Colors.green.shade500.withOpacity(0.1),
                          Colors.black.withOpacity(0.8),
                        ] 
                      : [
                          Colors.black.withOpacity(0.7),
                          Colors.green.shade900.withOpacity(0.6),
                          Colors.black.withOpacity(1),
                        ])  
                  : (isLargeScreen 
                      ? [
                          Colors.white.withOpacity(0),
                          Colors.green.shade300.withOpacity(0.06),
                          Colors.white.withOpacity(0.4),
                        ]
                      : [
                          Colors.white,
                          Colors.white.withOpacity(0.85),
                          Colors.white,
                        ]),
                stops: const [0.0, 0.5, 1.0],
              ),
            ),
            child: SafeArea(
              child: Stack(
                children: [
                  SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 32.0),
                    child: Form(
                      key: _formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 60),
                          
                          // App Icon
                          Container(
                            width: 64,
                            height: 64,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Colors.green.shade600,
                                  Colors.green.shade800,
                                ],
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.green.shade300.withOpacity(0.4),
                                  blurRadius: 12,
                                  offset: const Offset(0, 6),
                                ),
                              ],
                            ),
                            child: const Icon(
                              Icons.login,
                              color: Colors.white,
                              size: 32,
                            ),
                          ),
                          
                          const SizedBox(height: 48),
                          
                          // Welcome Text
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'مرحباً',
                                style: TextStyle(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w300,
                                  color: isDark ? Colors.white70 : Colors.black87,
                                  height: 1.2,
                                ),
                              ),
                              Text(
                                'بعودتك',
                                style: TextStyle(
                                  fontSize: 34,
                                  fontWeight: FontWeight.bold,
                                  color: isDark ? Colors.green.shade300 : Colors.green.shade800,
                                  height: 1.1,
                                ),
                              ),
                            ],
                          ),
                          
                          const SizedBox(height: 16),
                          
                          Text(
                            'سجل دخولك للمتابعة',
                            style: TextStyle(
                              fontSize: 18,
                              color: isDark ? const Color.fromARGB(255, 217, 255, 218) : const Color.fromARGB(255, 0, 93, 5),
                              height: 1.5,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                          
                          SizedBox(height: isLargeScreen ? size.height * 0.15 : size.height * 0.05),
                          
                          // // Phone Number Field
                          // CustomTextField(
                          //   controller: _phoneController,
                          //   label: 'رقم الهاتف',
                          //   labelColor: isDark ? Colors.white : Colors.black,
                          //   boxcolor: isDark ? const Color.fromARGB(255, 157, 42, 42) : Colors.black,
                          //   keyboardType: TextInputType.phone,
                          //   validator: (v) => v!.isEmpty ? 'رقم الهاتف مطلوب' : null,
                          //   prefixIcon: Icons.phone,
                          //   hint: '0xxxxxxxx',
                          // ),
                          
                          _AnimatedWidget(
                            slideAnimation: slideAnimation,
                            fadeAnimation: fadeAnimation,
                            slideMultiplier: 0.5,
                            child: _AnimatedUnderlineTextField(
                              controller: _phoneController,
                              label: ' رقم هاتف العريس',
                              // label: 'رقم الهاتف (رقم هاتف العريس) ',
                              labelColor: isDark ? Colors.white : Colors.black,
                              boxcolor: isDark ? const Color.fromARGB(255, 157, 42, 42) : Colors.black,
                              keyboardType: TextInputType.phone,
                              validator: validatePhone,
                              prefixIcon: Icons.phone,
                              hint: '0xxxxxxxx',
                            ),
                          ),
                          const SizedBox(height: 20),
                          
                          // Password Field
                          CustomTextField(
                            controller: _passwordController,
                            label: 'كلمة المرور',
                            labelColor: isDark ? Colors.white : Colors.black,
                            obscureText: _obscurePassword,
                            validator: (v) => v!.isEmpty ? 'كلمة المرور مطلوبة' : null,
                            prefixIcon: Icons.lock,
                            suffixIcon: IconButton(
                              icon: Icon(
                                _obscurePassword ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                            ),
                          ),
                          
                          const SizedBox(height: 16),
                          
                          // Forgot Password Link
                          Align(
                            alignment: Alignment.centerRight,
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => ForgotPasswordScreen()),
                                );
                              },
                              child: Text(
                                'نسيت كلمة المرور؟',
                                style: TextStyle(
                                  color: isDark ? Colors.green.shade300 : Colors.green.shade700,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                          ),
                          
                          const SizedBox(height: 40),
                          
                          // Login Button
                          SizedBox(
                            height: 48,
                            width: double.infinity,
                            child: ElevatedButton(
                              onPressed: _isLoading ? null : _login,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green.shade700,
                                foregroundColor: Colors.white,
                                elevation: 4,
                                shadowColor: Colors.green.shade300,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(24),
                                ),
                                disabledBackgroundColor: Colors.green.shade700.withOpacity(0.6),
                                padding: const EdgeInsets.symmetric(vertical: 2),
                              ),
                              child: _isLoading
                                ? const SizedBox(
                                    height: 20,
                                    width: 20,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                    ),
                                  )
                                : const Text(
                                    'تسجيل الدخول',
                                    style: TextStyle(
                                      fontSize: 16,  
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                            ),
                          ),
                          
                          const SizedBox(height: 24),
                          
                          // Signup Link
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'ليس لديك حساب؟ ',
                                style: TextStyle(
                                  color: isDark 
                                    ? isLargeScreen ? Colors.white70 : Colors.white70 
                                    : isLargeScreen ? Colors.green.shade900 : Colors.black87,
                                  fontWeight: isLargeScreen ? FontWeight.w800 : FontWeight.w600,
                                  fontSize: isLargeScreen ? 18 : 14,
                                ),
                              ),
                              GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) => MultiStepSignupScreen()),
                                  );
                                },
                                child: Text(
                                  'إنشاء حساب جديد',
                                  style: TextStyle(
                                    color: isDark ? Colors.green.shade300 : Colors.green.shade700,
                                    fontWeight: FontWeight.w800,
                                    fontSize: 14,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          
                          const SizedBox(height: 40),
                        ],
                      ),
                    ),
                  ),
                  
                  // Back Button
                  Positioned(
                    top: 8,
                    right: 16,
                    child: Material(
                      color: Colors.transparent,
                      child: IconButton(
                        onPressed: () {
                          Navigator.pushReplacement(
                            context,
                            PageRouteBuilder(
                              pageBuilder: (context, animation, secondaryAnimation) => WelcomeScreen(),
                              transitionsBuilder: (context, animation, secondaryAnimation, child) {
                                return FadeTransition(opacity: animation, child: child);
                              },
                              transitionDuration: const Duration(milliseconds: 200),
                            ),
                          );
                        },
                        icon: Icon(
                          Icons.arrow_back,
                          color: isDark ? Colors.green.shade300 : Colors.green.shade700,
                          size: 24,
                        ),
                      ),
                    ),
                  ),
                  
                  // Theme Toggle
                  Positioned(
                    top: 8,
                    left: 16,
                    child: ThemeToggleButton(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}


// Replace the _AnimatedUnderlineTextField widget with this updated version:
class _AnimatedUnderlineTextField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final Color labelColor;
  final Color boxcolor;
  final TextInputType keyboardType;
  final String? Function(String?)? validator;
  final IconData prefixIcon;
  final String hint;

  const _AnimatedUnderlineTextField({
    required this.controller,
    required this.label,
    required this.labelColor,
    required this.boxcolor,
    required this.keyboardType,
    this.validator,
    required this.prefixIcon,
    required this.hint,
  });

  @override
  State<_AnimatedUnderlineTextField> createState() => _AnimatedUnderlineTextFieldState();
}

class _AnimatedUnderlineTextFieldState extends State<_AnimatedUnderlineTextField> 
    with SingleTickerProviderStateMixin {
  late AnimationController _underlineController;
  late Animation<double> _underlineAnimation;
  final GlobalKey _labelKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    _underlineController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    )..repeat(reverse: true);

    _underlineAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _underlineController,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _underlineController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Label with animated underline
        Stack(
          clipBehavior: Clip.none,
          children: [
            Text(
              widget.label,
              key: _labelKey,
              style: TextStyle(
                color: widget.labelColor,
                fontSize: 15,
                fontWeight: FontWeight.w600,
              ),
            ),
            Positioned(
              bottom: -4,
              left: 0,
              right: 0,
              child: AnimatedBuilder(
                animation: _underlineAnimation,
                builder: (context, child) {
                  return CustomPaint(
                    size: Size(double.infinity, 3),
                    painter: _MovingUnderlinePainter(
                      progress: _underlineAnimation.value,
                      color: Colors.green,
                    ),
                  );
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        // Text field without label
        CustomTextField(
          controller: widget.controller,
          label: '', // Empty label since we show it above
          labelColor: widget.labelColor,
          boxcolor: widget.boxcolor,
          keyboardType: widget.keyboardType,
          validator: widget.validator,
          prefixIcon: widget.prefixIcon,
          hint: widget.hint,
        ),
      ],
    );
  }
}


// Reusable animated widget wrapper
class _AnimatedWidget extends StatelessWidget {
  final Animation<double> slideAnimation;
  final Animation<double> fadeAnimation;
  final Widget child;
  final double slideMultiplier;
  final double opacity;

  const _AnimatedWidget({
    required this.slideAnimation,
    required this.fadeAnimation,
    required this.child,
    this.slideMultiplier = 1.0,
    this.opacity = 1.0,
  });

  @override
  Widget build(BuildContext context) {
    return Transform.translate(
      offset: Offset(0, slideAnimation.value * slideMultiplier),
      child: Opacity(
        opacity: fadeAnimation.value * opacity,
        child: child,
      ),
    );
  }
}

// Keep the _MovingUnderlinePainter class as is (no changes needed)
class _MovingUnderlinePainter extends CustomPainter {
  final double progress;
  final Color color;

  _MovingUnderlinePainter({
    required this.progress,
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;

    final lineWidth = size.width * 0.3; // 30% of total width
    final startX = (size.width - lineWidth) * progress;
    final endX = startX + lineWidth;

    canvas.drawLine(
      Offset(startX, size.height / 2),
      Offset(endX, size.height / 2),
      paint,
    );
  }

  @override
  bool shouldRepaint(_MovingUnderlinePainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}
