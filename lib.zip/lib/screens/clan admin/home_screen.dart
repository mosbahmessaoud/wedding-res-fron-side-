// lib/screens/home/clan_admin_home_screen.dart
import 'dart:async';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/HallsTab.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/clan_admin_statistics_page.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/clan_rules_management_page.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/clan_settings_tab.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/food_menu_tab.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/groom_access_password_page.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/grooms_tab.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/home_tab.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/notifications_tab.dart'; // Added
import 'package:wedding_reservation_app/screens/clan%20admin/reservations_tab.dart';
import 'package:wedding_reservation_app/screens/clan%20admin/special_reservations_tab.dart';
import 'package:wedding_reservation_app/services/notification_manager.dart';
import 'package:wedding_reservation_app/services/token_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:wedding_reservation_app/services/notification_service.dart';
import 'package:wedding_reservation_app/services/foreground_notification_service.dart';
import '../../services/api_service.dart';
import '../../utils/colors.dart';
import '../../utils/constants.dart';

class ClanAdminHomeScreen extends StatefulWidget {
  const ClanAdminHomeScreen({super.key});

  @override
  _ClanAdminHomeScreenState createState() => _ClanAdminHomeScreenState();
}

class _ClanAdminHomeScreenState extends State<ClanAdminHomeScreen>
    with TickerProviderStateMixin {
  int _currentIndex = 0;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late AnimationController _refreshAnimationController;
  late Animation<double> _refreshAnimation;
  int _lastTabIndex = 0;
  int? _clanId;
  String? _clanName;




  // ADD THESE NEW VARIABLES:
  bool _hasAccessPassword = false;
  bool _isVerifyingAccess = false;
  bool _isVerifyingPassword = false;

  // ADD THESE NEW VARIABLES FOR BOTTOM NAV VISIBILITY:
  bool _isBottomNavVisible = true;
  Timer? _hideNavTimer;
  late AnimationController _navAnimationController;
  late Animation<Offset> _navSlideAnimation;

  // List of protected tab indices
  final List<int> _protectedTabs = [1, 5, 6, 7, 8, 10,11]; // Halls, Grooms, Settings, Notif, Rules, Special Reserv, Password Management
  
  // Tab keys for refreshing specific tabs
  final GlobalKey<FoodTabState> _foodTabKey = GlobalKey<FoodTabState>();
  final GlobalKey<HomeTabState> _homeTabKey = GlobalKey<HomeTabState>();
  final GlobalKey<HallsTabState> _hallsTabKey = GlobalKey<HallsTabState>();
  final GlobalKey<GroomManagementScreenState> _groomsTabKey = GlobalKey<GroomManagementScreenState>();
  final GlobalKey<SettingsTabState> _settingsTabKey = GlobalKey<SettingsTabState>();
  final GlobalKey<NotificationsTabState> _notifTabKey = GlobalKey<NotificationsTabState>();
  final GlobalKey<ClanRulesPageState> _rulesTabKey = GlobalKey<ClanRulesPageState>();
  final GlobalKey<SpecialReservationsTabState> _reserv_special = GlobalKey<SpecialReservationsTabState>();
  final GlobalKey<NotificationsTabState> _notificationsTabKey = GlobalKey<NotificationsTabState>(); // Added
  final GlobalKey<GroomAccessPasswordPageState> _groomPasswordTabKey = GlobalKey<GroomAccessPasswordPageState>();
  final GlobalKey<ReservationsTabState> _reservationsTabKey = GlobalKey<ReservationsTabState>();
  final GlobalKey<ClanAdminStatisticsPageState> _statisticsTabKey = GlobalKey<ClanAdminStatisticsPageState>();
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: Duration(milliseconds: 1200),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _refreshAnimationController = AnimationController(
      duration: Duration(milliseconds: 600),
      vsync: this,
    );
    _refreshAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _refreshAnimationController, curve: Curves.elasticOut),
    );

    _animationController.forward();
    _loadClanInfo();
    _checkAccessPassword(); // ADD THIS LINE



    // ADD THIS INITIALIZATION FOR NAV ANIMATION:
    _navAnimationController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    
    _navSlideAnimation = Tween<Offset>(
      begin: const Offset(0, 1), // Hidden below screen
      end: Offset.zero, // Visible
    ).animate(CurvedAnimation(
      parent: _navAnimationController,
      curve: Curves.easeInOut,
    ));
    
    // Show nav initially
    _navAnimationController.forward();
    _startHideTimer();
  

  }

// ADD THIS NEW METHOD:
Future<void> _checkAccessPassword() async {
  try {
    final hasPassword = await ApiService.hasAccessPassword();
    setState(() {
      _hasAccessPassword = hasPassword;
    });
  } catch (e) {
    print('Error checking access password: $e');
    setState(() {
      _hasAccessPassword = false;
    });
  }
}
  Future<void> _loadClanInfo() async {
    try {
      final clanInfo = await ApiService.getClanInfoByCurrentUser();
      setState(() {
        _clanId = clanInfo['id'];
        _clanName = clanInfo['name'] ?? 'العشيرة';
      });
    } catch (e) {
      print('Error loading clan info: $e');
      // Set default values if loading fails
      setState(() {
        _clanId = 0;
        _clanName = 'العشيرة';
      });
    }
  }

  @override
  void dispose() {
    _animationController.dispose();
    _refreshAnimationController.dispose();
    _hideNavTimer?.cancel();
    _navAnimationController.dispose();
    super.dispose();
    
      }

  @override
  void didUpdateWidget(ClanAdminHomeScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
  }

// ADD THESE NEW METHODS:
  void _startHideTimer() {
    _hideNavTimer?.cancel();
    _hideNavTimer = Timer(const Duration(seconds: 5), () {
      if (mounted) {
        _hideBottomNav();
      }
    });
  }

  void _hideBottomNav() {
    setState(() {
      _isBottomNavVisible = false;
    });
    _navAnimationController.reverse();
  }

  void _showBottomNav() {
    setState(() {
      _isBottomNavVisible = true;
    });
    _navAnimationController.forward();
    _startHideTimer();
  }

  // UPDATED METHOD - Prevents duplicate calls and shows loading
Future<bool> _verifyAccessForTab(int tabIndex) async {
  print('Verifying access for tab index: $tabIndex');
  
  // Check if tab requires protection
  if (!_protectedTabs.contains(tabIndex)) {
    return true; // Not a protected tab, allow access
  }
  
  // Prevent multiple simultaneous verifications
  if (_isVerifyingPassword) {
    return false;
  }
  
  setState(() {
    _isVerifyingPassword = true;
  });
  
  try {
    await _checkAccessPassword();
    
    // Check if user has access password set
    if (!_hasAccessPassword) {
      _showAccessPasswordNotSetDialog();
      return false;
    }

    // Show password verification dialog
    return await _showAccessPasswordDialog();
  } finally {
    if (mounted) {
      setState(() {
        _isVerifyingPassword = false;
      });
    }
  }
}
// Dialog when user doesn't have access password
void _showAccessPasswordNotSetDialog() {
  final isDark = Theme.of(context).brightness == Brightness.dark;
  
  showDialog(
    context: context,
    builder: (context) => AlertDialog(
      backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: Row(
        children: [
          Icon(Icons.lock_outline, color: Colors.orange),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'كلمة مرور الوصول غير متوفرة',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: isDark ? Colors.white : Colors.black87,
              ),
            ),
          ),
        ],
      ),
      // content: Text(
      //   'لم يتم تعيين كلمة مرور وصول لحسابك.\nيرجى الاتصال بالمدير الأعلى لإنشاء كلمة مرور.',
      //   style: TextStyle(
      //     color: isDark ? Colors.white70 : Colors.black87,
      //   ),
      // ),
      actions: [
        ElevatedButton(
          onPressed: () => Navigator.pop(context),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.primary,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
          ),
          child: const Text('فهمت', style: TextStyle(color: Colors.white)),
        ),
      ],
    ),
  );
}
// Updated _showAccessPasswordDialog method with loading state

Future<bool> _showAccessPasswordDialog() async {
  final isDark = Theme.of(context).brightness == Brightness.dark;
  final passwordController = TextEditingController();
  bool obscurePassword = true;
  String? errorMessage;
  bool isLoading = false; // ADD THIS LINE

  final result = await showDialog<bool>(
    context: context,
    barrierDismissible: false,
    builder: (context) => StatefulBuilder(
      builder: (context, setDialogState) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            Icon(Icons.key, color: AppColors.primary),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                'أدخل كلمة مرور الوصول',
                style: TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 18,
                  color: isDark ? Colors.white : Colors.black87,
                ),
              ),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Container(
            //   padding: const EdgeInsets.all(12),
            //   decoration: BoxDecoration(
            //     color: Colors.blue.shade50,
            //     borderRadius: BorderRadius.circular(8),
            //     border: Border.all(color: Colors.blue.shade200),
            //   ),
            //   child: Row(
            //     children: const [
            //       Icon(Icons.info_outline, color: Colors.blue, size: 20),
            //       SizedBox(width: 8),
            //       Expanded(
            //         child: Text(
            //           'هذه الصفحة محمية. يرجى إدخال كلمة المرور.',
            //           style: TextStyle(color: Colors.blue, fontSize: 12),
            //         ),
            //       ),
            //     ],
            //   ),
            // ),
            // SizedBox(height: 16),
            TextField(
              controller: passwordController,
              obscureText: obscurePassword,
              autofocus: true,
              enabled: !isLoading, // DISABLE WHEN LOADING
              style: TextStyle(
                color: isDark ? Colors.white : Colors.black87,
              ),
              decoration: InputDecoration(
                labelText: 'كلمة مرور ',
                hintText: 'أدخل كلمة المرور',
                prefixIcon: const Icon(Icons.lock_outline),
                suffixIcon: IconButton(
                  icon: Icon(
                    obscurePassword ? Icons.visibility : Icons.visibility_off,
                  ),
                  onPressed: isLoading ? null : () { // DISABLE WHEN LOADING
                    setDialogState(() {
                      obscurePassword = !obscurePassword;
                    });
                  },
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                errorText: errorMessage,
              ),
              onSubmitted: isLoading ? null : (_) async { // DISABLE WHEN LOADING
                if (passwordController.text.isEmpty) {
                  setDialogState(() {
                    errorMessage = 'يرجى إدخال كلمة المرور';
                  });
                  return;
                }
                
                // Start loading
                setDialogState(() {
                  isLoading = true;
                  errorMessage = null;
                }); 
                
                try {
                  final isValid = await ApiService.validateSpecialPageAccess(
                    passwordController.text,
                  );
                  if (isValid) {
                    Navigator.pop(context, true);
                  } else {
                    setDialogState(() {
                      isLoading = false;
                      errorMessage = 'كلمة المرور غير صحيحة';
                    });
                  }
                } catch (e) {
                  setDialogState(() {
                    isLoading = false;
                    errorMessage = 'خطأ في التحقق من كلمة المرور';
                  });
                }
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: isLoading ? null : () => Navigator.pop(context, false), // DISABLE WHEN LOADING
            child: Text(
              'إلغاء',
              style: TextStyle(
                color: isLoading 
                    ? Colors.grey 
                    : (isDark ? Colors.white60 : Colors.grey[700]),
              ),
            ),
          ),
          ElevatedButton(
            onPressed: isLoading ? null : () async { // DISABLE WHEN LOADING
              if (passwordController.text.isEmpty) {
                setDialogState(() {
                  errorMessage = 'يرجى إدخال كلمة المرور';
                });
                return;
              }

              // Start loading
              setDialogState(() {
                isLoading = true;
                errorMessage = null;
              });

              try {
                final isValid = await ApiService.validateSpecialPageAccess(
                  passwordController.text,
                );

                if (isValid) {
                  Navigator.pop(context, true);
                } else {
                  setDialogState(() {
                    isLoading = false;
                    errorMessage = 'كلمة المرور غير صحيحة';
                  });
                }
              } catch (e) {
                setDialogState(() {
                  isLoading = false;
                  errorMessage = 'خطأ في التحقق من كلمة المرور';
                });
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: isLoading 
                  ? Colors.grey 
                  : AppColors.primary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
            ),
            child: isLoading // UPDATED CHILD WITH LOADING INDICATOR
                ? Row(
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      ),
                      SizedBox(width: 8),
                      Text('جاري التحقق...', style: TextStyle(color: Colors.white)),
                    ],
                  )
                : const Text('تحقق', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    ),
  );

  passwordController.dispose();
  return result ?? false;
}

// UPDATED METHOD - Cleaner verification flow
void _navigateToTab(int index) async {
  // Prevent action if already verifying
  if (_isVerifyingPassword) {
    return;
  }
  
  // // Verify access for protected tabs
  // bool hasAccess = await _verifyAccessForTab(index);
  
  // if (!hasAccess) {
  //   return;
  // }
  
  final screenSize = MediaQuery.of(context).size;
  final isLargeScreen = screenSize.width > 1024;
  
  if (_lastTabIndex != index) {
    setState(() {
      _currentIndex = index;
    });
    
    _refreshCurrentTab(index);
    _lastTabIndex = index;
  } else {
    setState(() {
      _currentIndex = index;
    });
  }
  
  // Reset hide timer when navigating
  if (!isLargeScreen) {
    _startHideTimer();
  }
}


  // Method for refreshing specific tabs
  void _refreshCurrentTab(int index) {
    switch (index) {
      case 0:
        _homeTabKey.currentState?.refreshData();
        break;
      case 1:
        _hallsTabKey.currentState?.refreshData();
        break;
      case 2:
        _groomsTabKey.currentState?.refreshData();
        break;
      case 3:
        _reservationsTabKey.currentState?.refreshData();
        break;
      case 4:
        _foodTabKey.currentState?.refreshData();
        break;
      case 5:
        _settingsTabKey.currentState?.refreshData();
        break;
      case 6:
        _notifTabKey.currentState?.refreshData();
        break;
      case 7:
        _rulesTabKey.currentState?.refreshData();
        break;
      case 8:
        _reserv_special.currentState?.refreshData();
        break;
      case 9:
        _notificationsTabKey.currentState?.refreshData(); // Added
        break;
      case 10:
        _groomPasswordTabKey.currentState?.refreshData();
        break;
      case 11:
        _statisticsTabKey.currentState?.refreshData(); // ← NEW LINE
        break;
      case 12: // ← Update from 11 to 12 for profile
        break;
    }
  }

  void _notifyTabRefresh(int tabIndex) {
    _refreshCurrentTab(tabIndex);
  }

  // Show confirmation dialog for sign out
  void _showLogoutDialog() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF1E1E1E)  : Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'تسجيل الخروج',
          style: TextStyle(
            fontWeight: FontWeight.w600,
            color: isDark ? Colors.white : Colors.black87,
          ),
        ),
        content: Text(
          'هل أنت متأكد من رغبتك في تسجيل الخروج؟',
          style: TextStyle(
            color: isDark ? Colors.white70 : Colors.black87,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'إلغاء',
              style: TextStyle(color: isDark ? Colors.white60 : Colors.grey[700]),
            ),
          ),
          ElevatedButton(
            // onPressed: () async {
            //   await TokenManager.clearToken(); // ← ADD THIS
            //   await ApiService.clearToken();
            //   NotificationManager().stopMonitoring();
            //   await NotificationManager().cancelAllNotifications();
            //   if (!context.mounted) return; // ← ADD THIS
            //   Navigator.of(context).pushNamedAndRemoveUntil('/login', (route) => false);
            // },
            onPressed: () async {
            // ── 1. Clear auth token ──
            await TokenManager.clearToken();
            await ApiService.clearToken();
 
            // ── 2. Clear stored credentials from SharedPreferences ──
            final prefs = await SharedPreferences.getInstance();
            await prefs.remove('auth_token');
            await prefs.remove('user_role');
 
            // ── 3. Stop notification services & clear tracking ──
            await WeddingNotificationService().clearOnLogout();
            await WeddingForegroundNotificationService().stopService();
 
            if (!context.mounted) return;
            Navigator.of(context)
                .pushNamedAndRemoveUntil('/login', (route) => false);
          },
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
            ),
            child: const Text('تسجيل الخروج', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }



  // REPLACE THE build METHOD'S bottom navigation section with this:
  // build widget of clan admin 
  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final screenSize = MediaQuery.of(context).size;
    final isLargeScreen = screenSize.width > 1024;
    final isMobile = screenSize.width <= 480;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, dynamic result) {
        return;
      },
      child: Scaffold(
        backgroundColor: isDark ? const Color(0xFF1E1E1E) : Color(0xFFF8FAFC),
        body: Row(
          children: [
            if (isLargeScreen) _buildRightNavigation(isDark),
            
            Expanded(
              child: Stack(
                children: [
                  // Main content
                  Positioned.fill(
                    child: HeroMode(
                      enabled: false,
                      child: IndexedStack(
                        index: _currentIndex,
                        children: [
                        HomeTab(key: _homeTabKey, onNavigateToTab: _navigateToTab),
                        HallsTab(key: _hallsTabKey),
                        GroomManagementScreen(key: _groomsTabKey),
                        ReservationsTab(key: _reservationsTabKey),
                        FoodTab(key: _foodTabKey),
                        SettingsTab(key: _settingsTabKey),
                        NotificationsTab(key: _notifTabKey),    
                         

                         
                        if (_clanId != null && _clanName != null)
                          ClanRulesPage(key: _rulesTabKey)
                        else
                          Center(child: CircularProgressIndicator(color: AppColors.primary)),
                        SpecialReservationsTab(key: _reserv_special),
                        NotificationsTab(key: _notificationsTabKey), // Added
                        GroomAccessPasswordPage(key: _groomPasswordTabKey), // ← NEW LINE
                        ClanAdminStatisticsPage(key: _statisticsTabKey), // ← NEW LINE

                        _buildProfileTab(isDark),
                      ],
                    ),
                  ),
                ),
                
                // UPDATED BOTTOM NAVIGATION SECTION:
                  if (!isLargeScreen) ...[
                    // Animated Bottom Navigation Bar
                    Positioned(
                      left: 0,
                      right: 0,
                      bottom: 0,
                      child: SlideTransition(
                        position: _navSlideAnimation,
                        child: _buildModernBottomNav(isMobile, isDark),
                      ),
                    ),
                    
                    // Floating Show Button (appears when nav is hidden)
                    if (!_isBottomNavVisible)
                      Positioned(
                        bottom: 30,
                        right: 16,
                        child: _buildShowNavButton(isDark),
                      ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

   // ADD THIS NEW METHOD FOR THE SHOW BUTTON:
  Widget _buildShowNavButton(bool isDark) {
    return GestureDetector(
      onTap: _showBottomNav,
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          // border: Border.all(color: AppColors.primary.withOpacity(0.9)),
          gradient: LinearGradient(
            colors: [
              isDark ? Color.fromARGB(204, 46, 125, 50) : const Color.fromARGB(188, 34, 123, 38),
              isDark ? Color.fromARGB(196, 46, 125, 50) : const Color.fromARGB(166, 25, 120, 30),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(35),
          // boxShadow: [
          //   BoxShadow(
          //     color: AppColors.primary.withOpacity(0.4),
          //     blurRadius: 12,
          //     offset: const Offset(0, 3),
          //   ),
          // ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.menu,
              color: isDark ? Colors.white : Colors.white,
              size: 20,
            ),
            // const SizedBox(width: 8),
            // Text(
            //   'القائمة',
            //   style: TextStyle(
            //     color: Colors.white,
            //     fontSize: 14,
            //     fontWeight: FontWeight.w600,
            //   ),
            // ),
          ],
        ),
      ),
    );
  }


  Widget _buildRightNavigation(bool isDark) {
    return Container(
      width: 280,
      decoration: BoxDecoration(
        color: isDark 
            ? const Color.fromARGB(255, 16, 21, 27).withOpacity(0.7)
            : const Color.fromARGB(47, 79, 79, 79),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDark ? 0.3 : 0.08),
            blurRadius: 25,
            offset: const Offset(4, 0),
            spreadRadius: 5,
          ),
          BoxShadow(
            color: const Color.fromARGB(255, 7, 179, 16).withOpacity(0.3),
            blurRadius: 25,
            offset: const Offset(4, 0),
            spreadRadius: 10,
          ),
        ],
      ),
      child: ClipRRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
          child: SafeArea(
            child: Column(
              children: [
                // Logo/Header Section
                Container(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              AppColors.primary,
                              AppColors.primary.withOpacity(0.7),
                            ],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          borderRadius: BorderRadius.circular(20),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.withOpacity(0.3),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.admin_panel_settings,
                          color: Colors.white,
                          size: 40,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        'لوحة التحكم',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                          color: isDark ? Colors.white : Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
                
                Divider(
                  color: isDark ? Colors.white12 : Colors.white24,
                  height: 1,
                ),
                
                // Navigation Items
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                    children: [
                      _buildRightNavItem(Icons.home_rounded, 'الرئيسية', 0, isDark),
                      _buildRightNavItem(Icons.castle_outlined, 'القاعات', 1, isDark),
                      _buildRightNavItem(Icons.group_outlined, 'العرسان', 2, isDark),
                      _buildRightNavItem(Icons.book_outlined, 'الحجوزات', 3, isDark),
                      _buildRightNavItem(Icons.restaurant_menu_outlined, 'قوائم الطعام', 4, isDark),
                      _buildRightNavItem(Icons.settings_outlined, 'الإعدادات', 5, isDark),
                      // _buildRightNavItem(Icons.lock_outline, 'رموز التحقق', 6, isDark),
                      _buildRightNavItem(Icons.rule_outlined, 'اللوازم ', 7, isDark),
                      _buildRightNavItem(Icons.star_border_outlined, 'الحجوزات الخاصة', 8, isDark),
                      _buildRightNavItem(Icons.notifications_outlined, 'الإشعارات', 9, isDark), // Added
                      _buildRightNavItem(Icons.lock_outline, 'كلمة مرور الوصول', 10, isDark),
                      _buildRightNavItem(Icons.bar_chart_outlined, 'الإحصائيات', 11, isDark), // ← NEW LINE
                      // _buildRightNavItem(Icons.person_outline, 'الملف الشخصي', 10, isDark), // Changed from 9 to 10                  
                    ],
                  ),
                ),
                
                // Footer Section
                Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Divider(
                        color: isDark ? Colors.white12 : Colors.white24,
                        height: 1,
                      ),
                      const SizedBox(height: 16),
                      _buildRightNavLogoutButton(isDark),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Widget _buildRightNavItem(IconData icon, String label, int index, bool isDark) {
  //   final isSelected = _currentIndex == index;
    
  //   return GestureDetector(
  //     onTap: () => _navigateToTab(index),
  //     child: AnimatedContainer(
  //       duration: const Duration(milliseconds: 300),
  //       curve: Curves.easeOutCubic,
  //       margin: const EdgeInsets.symmetric(vertical: 4),
  //       padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
  //       decoration: BoxDecoration(
  //         gradient: isSelected
  //             ? LinearGradient(
  //                 colors: [
  //                   AppColors.primary.withOpacity(0.8),
  //                   AppColors.primary.withOpacity(0.5),
  //                 ],
  //                 begin: Alignment.topLeft,
  //                 end: Alignment.bottomRight,
  //               )
  //             : null,
  //         color: !isSelected && isDark ? Colors.white.withOpacity(0.05) : Colors.white.withOpacity(0.2) ,
  //         borderRadius: BorderRadius.circular(12),
  //         boxShadow: isSelected
  //             ? [
  //                 BoxShadow(
  //                   color: AppColors.primary.withOpacity(0.3),
  //                   blurRadius: 12,
  //                   offset: const Offset(0, 4),
  //                 ),
  //               ]
  //             : null,
  //       ),
  //       child: Row(
  //         children: [
  //           Icon(
  //             icon,
  //             color: isSelected 
  //                 ? Colors.white 
  //                 : (isDark ? Colors.white70 : Colors.black.withOpacity(0.5)),
  //             size: 24,
  //           ),
  //           const SizedBox(width: 16),
  //           Expanded(
  //             child: Text(
  //               label,
  //               style: TextStyle(
  //                 fontSize: 15,
  //                 fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
  //                 color: isSelected 
  //                     ? Colors.white 
  //                     : (isDark ? Colors.white70 : Colors.black.withOpacity(0.6)),
  //                 letterSpacing: 0.2,
  //               ),
  //             ),
  //           ),
  //           if (isSelected)
  //             Container(
  //               width: 4,
  //               height: 4,
  //               decoration: const BoxDecoration(
  //                 color: Colors.white,
  //                 shape: BoxShape.circle,
  //               ),
  //             ),
  //         ],
  //       ),
  //     ),
  //   );
  // }

Widget _buildRightNavItem(IconData icon, String label, int index, bool isDark) {
  final isSelected = _currentIndex == index;
  final isProtected = _protectedTabs.contains(index);
  
  return GestureDetector(
    onTap: () {
      // Prevent action if already verifying
      if (_isVerifyingPassword) {
        return;
      }
      _navigateToTab(index);
    },
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOutCubic,
      margin: const EdgeInsets.symmetric(vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        gradient: isSelected
            ? LinearGradient(
                colors: [
                  AppColors.primary.withOpacity(0.8),
                  AppColors.primary.withOpacity(0.5),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        color: !isSelected && isDark ? Colors.white.withOpacity(0.05) : Colors.white.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        boxShadow: isSelected
            ? [
                BoxShadow(
                  color: AppColors.primary.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: Row(
        children: [
          Stack(
            children: [
              Icon(
                icon,
                color: isSelected 
                    ? Colors.white 
                    : (isDark ? Colors.white70 : Colors.black.withOpacity(0.5)),
                size: 24,
              ),
              // Show lock badge for protected tabs
              if (isProtected && !isSelected)
                Positioned(
                  right: -2,
                  top: -2,
                  child: Container(
                    padding: const EdgeInsets.all(2),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: isDark ? const Color(0xFF1E1E1E) : Colors.white,
                        width: 1,
                      ),
                    ),
                    child: const Icon(
                      Icons.lock,
                      size: 8,
                      color: Colors.white,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontSize: 15,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                color: isSelected 
                    ? Colors.white 
                    : (isDark ? Colors.white70 : Colors.black.withOpacity(0.6)),
                letterSpacing: 0.2,
              ),
            ),
          ),
          if (isSelected)
            Container(
              width: 4,
              height: 4,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
            ),
        ],
      ),
    ),
  );
}

  Widget _buildRightNavLogoutButton(bool isDark) {
    return GestureDetector(
      onTap: _showLogoutDialog,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(isDark ? 0.15 : 0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Colors.red.withOpacity(isDark ? 0.4 : 0.3),
            width: 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.logout_rounded,
              color: isDark ? Colors.red[300] : const Color.fromARGB(255, 161, 25, 25),
              size: 24,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                'تسجيل الخروج',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: isDark ? Colors.red[300] : const Color.fromARGB(255, 161, 25, 25),
                  letterSpacing: 0.2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // PreferredSizeWidget _buildAppBar(bool isMobile, bool isDark) {
  //   return AppBar(
  //     title: Text(
  //       _getAppBarTitle(),
  //       style: TextStyle(
  //         fontSize: 20,
  //         fontWeight: FontWeight.w700,
  //         letterSpacing: -0.5,
  //         color: isDark ? Colors.white : Colors.black87,
  //       ),
  //     ),
  //     backgroundColor: isDark 
  //         ? AppColors.surfaceVariant.withOpacity(0.9)
  //         : const Color.fromARGB(201, 255, 255, 255),
  //     foregroundColor: isDark ? Colors.white : Colors.black87,
  //     elevation: 0,
  //     automaticallyImplyLeading: false,
  //     actions: [
  //       IconButton(
  //         icon: Stack(
  //           children: [
  //             Container(
  //               padding: const EdgeInsets.all(6),
  //               decoration: BoxDecoration(
  //                 color: isDark ? Colors.grey[800] : Colors.grey[100],
  //                 borderRadius: BorderRadius.circular(8),
  //               ),
  //               child: Icon(
  //                 Icons.notifications_outlined,
  //                 size: 20,
  //                 color: isDark ? Colors.white : Colors.black87,
  //               ),
  //             ),
  //             Positioned(
  //               right: 4,
  //               top: 4,
  //               child: Container(
  //                 width: 8,
  //                 height: 8,
  //                 decoration: BoxDecoration(
  //                   color: AppColors.primary,
  //                   shape: BoxShape.circle,
  //                 ),
  //               ),
  //             ),
  //           ],
  //         ),
  //         onPressed: () {
  //           _navigateToTab(9); // Navigate to notifications tab
  //         },
  //       ),
  //       const SizedBox(width: 4),
  //       IconButton(
  //         icon: Container(
  //           padding: const EdgeInsets.all(6),
  //           decoration: BoxDecoration(
  //             color: isDark ? Colors.grey[800] : Colors.grey[100],
  //             borderRadius: BorderRadius.circular(8),
  //           ),
  //           child: Icon(
  //             isDark ? Icons.light_mode_outlined : Icons.dark_mode_outlined,
  //             size: 20,
  //             color: isDark ? Colors.white : Colors.black87,
  //           ),
  //         ),
  //         onPressed: () {
  //           final themeProvider = Provider.of<ThemeProvider>(context, listen: false);
  //           themeProvider.toggleTheme();
  //         },
  //         tooltip: isDark ? 'الوضع الفاتح' : 'الوضع الداكن',
  //       ),
  //       const SizedBox(width: 8),
  //       IconButton(
  //         icon: Container(
  //           padding: const EdgeInsets.all(6),
  //           decoration: BoxDecoration(
  //             color: isDark ? Colors.grey[800] : Colors.grey[100],
  //             borderRadius: BorderRadius.circular(8),
  //           ),
  //           child: Icon(
  //             Icons.logout_outlined,
  //             size: 20,
  //             color: isDark ? Colors.white : Colors.black87,
  //           ),
  //         ),
  //         onPressed: _showLogoutDialog,
  //         tooltip: 'تسجيل الخروج',
  //       ),
  //       const SizedBox(width: 8),
  //     ],
  //   );
  // }
// UPDATE _buildModernBottomNav to handle tap events that reset timer:
  Widget _buildModernBottomNav(bool isMobile, bool isDark) {
    return GestureDetector(
      onTap: _startHideTimer, // Reset timer on any tap
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 0, horizontal: 0),
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          color: isDark 
              ? const Color.fromARGB(57, 248, 249, 250).withOpacity(0.2)
              : const Color.fromARGB(105, 79, 79, 79),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(isDark ? 0.3 : 0.08),
              blurRadius: 25,
              offset: const Offset(0, -4),
              spreadRadius: 2,
            ),
            BoxShadow(
              color: AppColors.primary.withOpacity(0.3),
              blurRadius: 25,
              offset: const Offset(0, -4),
              spreadRadius: 0,
            ),
          ],
          border: Border.all(
            color: AppColors.primary.withOpacity(isDark ? 0.2 : 0.3),
            width: 0,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(25),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
            child: SafeArea(
              bottom: true,
              top: false,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    _buildNavItem(Icons.castle_outlined, 'القاعات', 1, isDark),
                    _buildNavItem(Icons.group_outlined, 'العرسان', 2, isDark),
                    _buildNavItem(Icons.book_outlined, 'الحجوزات', 3, isDark),
                    _buildNavItem(Icons.home_rounded, 'الرئيسية', 0, isDark),
                    _buildNavItem(Icons.restaurant_menu_outlined, 'الطعام', 4, isDark),
                    _buildNavItem(Icons.settings_outlined, 'الإعدادات', 5, isDark),
                    _buildNavItem(Icons.notifications_outlined, 'الإشعارات', 9, isDark),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
    


  Widget _buildNavItem(IconData icon, String label, int index, bool isDark) {
  final isSelected = _currentIndex == index;
  
  return GestureDetector(
    onTap: () {
      // Prevent action if already verifying
      if (_isVerifyingPassword) {
        return;
      }
      _navigateToTab(index);
    },
    behavior: HitTestBehavior.opaque,
    child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOutCubic,
        padding: EdgeInsets.symmetric(
          horizontal: isSelected ? 12 : 8,
          vertical: 8,
        ),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: [
                    AppColors.primary.withOpacity(0.8),
                    AppColors.primary.withOpacity(0.5),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          borderRadius: BorderRadius.circular(16),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppColors.primary.withOpacity(0.3),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: isSelected 
                  ? Colors.white 
                  : (isDark ? Colors.white70 : Colors.black.withOpacity(0.5)),
              size: isSelected ? 22 : 20,
            ),
            if (isSelected) ...[
              const SizedBox(height: 4),
              Text(
                label,
                style: const TextStyle(
                  fontSize: 9,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                  letterSpacing: 0.2,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ],
        ),
      ),
    );
  }

String _getAppBarTitle() {
  switch (_currentIndex) {
    case 0:
      return AppConstants.appName;
    case 1:
      return 'إدارة القاعات';
    case 2:
      return 'إدارة العرسان';
    case 3:
      return 'إدارة الحجوزات';
    case 4:
      return 'قوائم الطعام';
    case 5:
      return 'الإعدادات';
    case 6:
      return 'رموز التحقق'; 
    case 7:
      return 'قوانين العشيرة';
    case 8:
      return 'الحجوزات الخاصة';
    case 9:
      return 'الإشعارات'; // Added
    case 10:
      return 'كلمة مرور الوصول';
    case 11:
      return 'الإحصائيات'; // ← NEW LINE
    case 12: // ← Changed from 11 to 12
      return 'الملف الشخصي';
    default:
      return AppConstants.appName;
  }
}

  Widget _buildProfileTab(bool isDark) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppColors.primary.withOpacity(0.1),
                  AppColors.primary.withOpacity(0.05),
                ],
              ),
              shape: BoxShape.circle,
              border: Border.all(
                color: AppColors.primary.withOpacity(0.2),
                width: 2,
              ),
            ),
            child: Icon(
              Icons.person_outline,
              size: 48,
              color: AppColors.primary,
            ),
          ),
          SizedBox(height: 32),
          Text(
            'قريباً...',
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: isDark ? Colors.white : AppColors.textPrimary,
            ),
          ),
          SizedBox(height: 12),
          Text(
            'صفحة الملف الشخصي قيد التطوير',
            style: TextStyle(
              fontSize: 16,
              color: isDark ? Colors.white70 : AppColors.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 40),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(25),
              border: Border.all(
                color: AppColors.primary.withOpacity(0.2),
              ),
            ),
            child: Text(
              'سيتم إضافة المزيد من الميزات قريباً',
              style: TextStyle(
                color: AppColors.primary,
                fontSize: 14,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// FoodMenu model class
class FoodMenu {
  final int id;
  final String name;
  final String? description;
  final String foodType;
  final int visitors;
  final double price;
  final int clanId;
  final String? createdAt;

  FoodMenu({
    required this.id,
    required this.name,
    this.description,
    required this.foodType,
    required this.visitors,
    required this.price,
    required this.clanId,
    this.createdAt,
  });

  factory FoodMenu.fromJson(Map<String, dynamic> json) {
    return FoodMenu(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      description: json['description'],
      foodType: json['food_type'] ?? '',
      visitors: json['visitors'] ?? 0,
      price: (json['price'] ?? 0).toDouble(),
      clanId: json['clan_id'] ?? 0,
      createdAt: json['created_at'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'food_type': foodType,
      'visitors': visitors,
      'price': price,
      'clan_id': clanId,
      'created_at': createdAt,
    };
  }
}